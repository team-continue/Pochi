// Pochi D435 portrait bracket, millimetres. X forward, Y left, Z up.
// Same construction as generate.py; default 30 degrees below horizontal.
// F6, then File > Export > STL. Use print_pose=true for the print orientation.
angle = 30;
print_pose = false;
$fn = 96;
assert(angle >= 20 && angle <= 45);

function normal() = [cos(angle), 0, -sin(angle)];
function vertical() = [sin(angle), 0, cos(angle)];
function centre() = [12 + 45*sin(angle), 0, 2];

module cyl_x(r,h) { rotate([0,90,0]) cylinder(r=r,h=h,center=true); }
module rounded_plate(d,w,h,r=3) {
  union() {
    cube([d,w-2*r,h],center=true);
    cube([d,w,h-2*r],center=true);
    for(y=[-w/2+r,w/2-r], z=[-h/2+r,h/2-r])
      translate([0,y,z]) cyl_x(r,d);
  }
}
module camera_frame() { translate(centre()) rotate([0,angle,0]) children(); }
module web(sign) {
  hull() {
    for(y=[sign*20,sign*23]) {
      for(x=[4,6],z=[-29,29]) translate([x,y,z]) cube(.001,center=true);
      for(z=[-28,28],d=[-3.9,-.5]) {
        p=centre()+z*vertical()+d*normal();
        translate([p[0],y,p[2]]) cube(.001,center=true);
      }
    }
  }
}
module bracket() {
  difference() {
    union() {
      translate([3,0,0]) rounded_plate(6,46,64);
      camera_frame() translate([-2,0,0]) rounded_plate(4,46,74);
      web(-1); web(1);
    }
    for(y=[-15,15],z=[-24,24]) {
      translate([3,y,z]) cyl_x(1.7,10);
      translate([4.51,y,z]) cyl_x(3.3,3.02);
      translate([56.01,y,z]) cyl_x(3.7,100);
    }
    for(z=[-22.5,22.5]) camera_frame() translate([-2,0,z]) cyl_x(1.7,8);
    camera_frame() translate([-2,0,0]) rounded_plate(8,26,24);
    for(y=[-18,18]) camera_frame() translate([-2,y,0]) rounded_plate(8,3.2,8,1.5);
  }
}
// The minimum assembled Y is -23. The -90 degree rotation makes it print Z.
if(print_pose) translate([0,0,23]) rotate([-90,0,0]) bracket();
else bracket();
