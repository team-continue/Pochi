"""D435 portrait bracket. Millimetres; +X forward, +Y left, +Z up.

Run with pochi_rl/.venv/bin/python mechanical/d435_mount/generate.py.
Uses the existing trimesh/manifold3d environment; never modifies robot CAD.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

import manifold3d as mf
import numpy as np
import trimesh

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MESHES = ROOT / "pochi_rl/pkg_4leg_assem2/meshes"
BOARD = MESHES / "carbon_Body_plate3_x__3mm_x2_.stl"
ANGLES = (20, 25, 30, 35, 40, 45)
BOARD_HOLES = [(y, z) for y in (-15.0, 15.0) for z in (-24.0, 24.0)]
CAMERA_HOLES = (-22.5, 22.5)
CAMERA_DATASHEET = (
    "https://www.realsenseai.com/wp-content/uploads/2020/06/"
    "Intel-RealSense-D400-Series-Datasheet-June-2020.pdf#page=113"
)


def box(size, centre):
    return mf.Manifold.cube(size, center=True).translate(centre)


def cylinder_x(radius, length, centre, segments=96):
    return mf.Manifold.cylinder(
        length, radius, circular_segments=segments, center=True
    ).rotate((0, 90, 0)).translate(centre)


def rounded_plate(depth, width, height, radius=3):
    """Rounded YZ rectangle extruded along X, centred at the origin."""
    solids = [
        box((depth, width - 2 * radius, height), (0, 0, 0)),
        box((depth, width, height - 2 * radius), (0, 0, 0)),
    ]
    for y in (-width / 2 + radius, width / 2 - radius):
        for z in (-height / 2 + radius, height / 2 - radius):
            solids.append(cylinder_x(radius, depth, (0, y, z)))
    return mf.Manifold.batch_boolean(solids, mf.OpType.Add)


def camera_frame(angle):
    a = np.deg2rad(angle)
    normal = np.array([np.cos(a), 0.0, -np.sin(a)])
    vertical = np.array([np.sin(a), 0.0, np.cos(a)])
    # Maintain clearance even for the 90 mm camera at 45 degrees.
    centre = np.array([12.0 + 45.0 * np.sin(a), 0.0, 2.0])
    return normal, vertical, centre


def camera_transform(solid, angle):
    return solid.rotate((0, angle, 0)).translate(camera_frame(angle)[2])


def make_bracket(angle):
    base = rounded_plate(6, 46, 64).translate((3, 0, 0))
    carrier = camera_transform(
        rounded_plate(4, 46, 74).translate((-2, 0, 0)), angle
    )
    normal, vertical, centre = camera_frame(angle)
    # Two continuous 3 mm side webs. Keep the central screw driver route clear.
    webs = []
    for sign in (-1, 1):
        points = []
        for y in (sign * 20, sign * 23):
            points.extend([[4, y, -29], [4, y, 29], [6, y, -29], [6, y, 29]])
            for z in (-28, 28):
                for d in (-3.9, -0.5):
                    p = centre + vertical * z + normal * d
                    points.append([p[0], y, p[2]])
        webs.append(mf.Manifold.hull_points(points))
    bracket = mf.Manifold.batch_boolean([base, carrier, *webs], mf.OpType.Add)
    cuts = []
    for y, z in BOARD_HOLES:
        cuts.append(cylinder_x(1.7, 10, (3, y, z)))
        # M3 socket head seat, 3 mm deep. Retains 3 mm base material.
        cuts.append(cylinder_x(3.3, 3.02, (4.51, y, z)))
        # Pass the screw/head through the carrier wings, away from the optics.
        cuts.append(cylinder_x(3.7, 100, (56.01, y, z)))
    for z in CAMERA_HOLES:
        cuts.append(camera_transform(cylinder_x(1.7, 8, (-2, 0, z)), angle))
    # Open rear cooling window and two side cable tie slots; no front lips.
    cuts.append(camera_transform(rounded_plate(8, 26, 24).translate((-2, 0, 0)), angle))
    for y in (-18, 18):
        cuts.append(camera_transform(
            rounded_plate(8, 3.2, 8, radius=1.5).translate((-2, y, 0)), angle
        ))
    return mf.Manifold.batch_boolean([bracket, *cuts], mf.OpType.Subtract)


def mesh_of(solid):
    data = solid.to_mesh()
    return trimesh.Trimesh(
        vertices=np.asarray(data.vert_properties)[:, :3],
        faces=np.asarray(data.tri_verts), process=True,
    )


def board_mesh():
    mesh = trimesh.load_mesh(BOARD)
    mesh.apply_scale(1000)
    # CAD: lateral X, rearward -Y. Viewer/part: forward X, left Y.
    mesh.vertices = np.column_stack((mesh.vertices[:, 1], -mesh.vertices[:, 0], mesh.vertices[:, 2]))
    mesh.invert() if mesh.volume < 0 else None
    return mesh


def extract_holes(mesh):
    section = mesh.section(plane_origin=(-1.5, 0, 0), plane_normal=(1, 0, 0))
    holes = []
    for path in section.discrete:
        p = path[:, 1:3]
        fit = np.column_stack((2 * p[:, 0], 2 * p[:, 1], np.ones(len(p))))
        cy, cz, c = np.linalg.lstsq(fit, (p * p).sum(axis=1), rcond=None)[0]
        r = np.sqrt(c + cy**2 + cz**2)
        err = np.max(np.abs(np.linalg.norm(p - [cy, cz], axis=1) - r))
        if err < 0.03 and r < 8:
            holes.append({"y": float(cy), "z": float(cz), "diameter": float(2 * r), "fit_error": float(err)})
    return sorted(holes, key=lambda h: (round(h["z"], 1), h["y"]))


def validate(solid, mesh, holes, angle):
    assert solid.status() == mf.Error.NoError
    assert mesh.is_watertight and mesh.is_winding_consistent and mesh.is_volume
    assert len(mesh.split()) == 1, "Bracket must be one connected printable solid"
    errors = []
    for y, z in BOARD_HOLES:
        error = min(np.linalg.norm([h["y"] - y, h["z"] - z]) for h in holes if 3.2 < h["diameter"] < 3.4)
        assert error < 0.02, "A mounting hole does not match the source board"
        errors.append(float(error))
        # Actual material is absent along the M3 shank, and around the head seat.
        assert (solid ^ cylinder_x(1.5, 10, (3, y, z))).volume() < 0.001
        assert (solid ^ cylinder_x(3.0, 2.8, (4.5, y, z))).volume() < 0.001
    normal, vertical, centre = camera_frame(angle)
    for z in CAMERA_HOLES:
        bore = camera_transform(cylinder_x(1.5, 8, (-2, 0, z)), angle)
        assert (solid ^ bore).volume() < 0.001
        # The hole has a supporting 4 mm thick pad, rather than falling in a vent.
        sleeve = cylinder_x(3.3, 3.8, (-2, 0, z)) - cylinder_x(1.8, 4, (-2, 0, z))
        sleeve = camera_transform(sleeve, angle)
        assert (sleeve - solid).volume() < 0.01
    assert mesh.bounds[0, 0] > -0.0001, "Printed bracket must remain forward of the board"
    # Front roll motors occupy |Y| >= 30.75 mm in the source assembly.
    clearance = 30.75 - np.max(np.abs(mesh.vertices[:, 1]))
    assert clearance > 7.7
    assert np.allclose(normal @ vertical, 0)
    assert np.isclose(np.linalg.norm(vertical * 45), 45)
    camera = camera_transform(
        rounded_plate(25.05, 25, 90, 12.49).translate((12.525, 0, 0)), angle
    )
    overlap = float((solid ^ camera).volume())
    assert overlap < 0.001, "Printed bracket intrudes into the camera envelope"
    return {
        "angle_deg": angle, "watertight": True, "connected_components": 1,
        "bounds_mm": mesh.bounds.round(4).tolist(), "volume_cm3": round(mesh.volume / 1000, 3),
        "board_hole_centre_max_error_mm": max(errors),
        "motor_lateral_clearance_mm": round(float(clearance), 3),
        "camera_back_centre_mm": centre.round(5).tolist(),
        "optical_direction": normal.round(6).tolist(),
        "camera_envelope_overlap_mm3": overlap,
        "physical_fit_verified": False,
    }


def main():
    out = HERE / "exports"
    out.mkdir(exist_ok=True)
    board = board_mesh()
    holes = extract_holes(board)
    (out / "board_holes.json").write_text(json.dumps(holes, indent=2) + "\n")
    board.export(out / "reference_front_board_mm.stl")
    reports = []
    for angle in ANGLES:
        solid = make_bracket(angle)
        mesh = mesh_of(solid)
        report = validate(solid, mesh, holes, angle)
        name = f"d435_portrait_down{angle}"
        mesh.export(out / f"{name}_assembly_mm.stl")
        # Put the broad side on the bed. +Z is the printer build direction.
        printed = mesh.copy()
        printed.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, (1, 0, 0)))
        printed.apply_translation(-printed.bounds[0])
        assert printed.is_volume and np.min(printed.vertices[:, 2]) >= -1e-5
        printed.export(out / f"{name}_print_mm.stl")
        report["print_dimensions_mm"] = printed.extents.round(3).tolist()
        reports.append(report)
    manifest = {
        "units": "mm", "default_angle_deg": 30,
        "board_source": str(BOARD.relative_to(ROOT)),
        "board_sha256": hashlib.sha256(BOARD.read_bytes()).hexdigest(),
        "camera_source": CAMERA_DATASHEET,
        "board_fixing_centres_yz_mm": BOARD_HOLES,
        "camera_mount_pitch_mm": 45, "camera_mount_max_insertion_mm": 3,
        "base_thickness_mm": 6, "camera_pad_thickness_mm": 4,
        "camera_screws": "2 x M3x6 (2 mm nominal insertion without washer)",
        "variants": reports,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    archive = out / "pochi_d435_mount.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in [HERE / "generate.py", HERE / "viewer.py", HERE / "mount.scad", HERE / "README.md", *out.glob("*.stl"), *out.glob("*.json")]:
            if p.is_file():
                z.write(p, p.relative_to(HERE))
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
